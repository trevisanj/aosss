"""Widget to edit a FileSpectrumList object."""

__all__ = ["WFileSpectrumList"]

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from pyfant.gui.guiaux import *
from pyfant.gui import *
from pyfant import *
import random
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT # as NavigationToolbar2QT
import matplotlib.pyplot as plt
import numpy as np
from itertools import product, combinations, cycle
from filespectrumlist import *
# from fileccube import *
# from a_WChooseSpectrum import *
import os
import math
import numbers
import copy


class WFileSpectrumList(QWidget):
    """
    FileSpectrumList editor widget.

    Arguments:
      parent=None
    """

    # Emitted whenever any value changes
    edited = pyqtSignal()

    def __init__(self, parent=None):
        def keep_ref(obj):
            self.__refs.append(obj)
            return obj

        QWidget.__init__(self, parent)
        self.__refs = []
        # Whether all the values in the fields are valid or not
        self.flag_valid = False
        # Internal flag to prevent taking action when some field is updated programatically
        self.flag_process_changes = False
        # GUI update needed but cannot be applied immediately, e.g. visible range being edited
        self.flag_update_pending = False
        # Whether there is sth in yellow background in the Headers tab
        self.flag_header_changed = False
        self.f = None # FileSpectrumList object
        self.obj_square = None


        # # Central layout
        la = self.centralLayout = QVBoxLayout()
        la.setMargin(0)
        self.setLayout(la)

        # ## Vertical splitter with (main area) / (error area)
        sp = self.splitter = QSplitter(Qt.Vertical)
        la.addWidget(sp)


        # ### Horizontal splitter occupying main area: (options area) | (plot area)
        sp2 = self.splitter2 = QSplitter(Qt.Horizontal)


        # #### Tabbed widget occupying left of horizontal splitter (OPTIONS TAB)
        tt0 = self.tabWidgetOptions = QTabWidget(self)
        la.addWidget(tt0)
        tt0.setFont(MONO_FONT)
        tt0.currentChanged.connect(self.current_tab_changed_options)




        # ##### "Place Spectrum" Scroll area
        sa0 = keep_ref(QScrollArea())
        tt0.addTab(sa0, "spectra")
        sa0.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        sa0.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        # Widget that will be handled by the scrollable area
        scrw = self.scrollWidget = QWidget()
        sa0.setWidget(self.scrollWidget)
        sa0.setWidgetResizable(True)
#        la.addWidget(w)

        lscrw = QVBoxLayout()
        scrw.setLayout(lscrw)

        alabel = keep_ref(QLabel("Place spectrum"))
        lscrw.addWidget(alabel)


        # Form layout
        lg = keep_ref(QGridLayout())
        lscrw.addLayout(lg)
        lg.setMargin(0)
        lg.setVerticalSpacing(4)
        lg.setHorizontalSpacing(5)
        lscrw.addSpacerItem(QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Expanding))

        # field map: [(label widget, edit widget, field name, short description, long description), ...]
        pp = self._map0 = []
        #####
        x = self.label_sp = QLabel()
        y = self.choosesp = WChooseSpectrum()
        y.installEventFilter(self)
        y.edited.connect(self.on_colors_setup_edited)
        # y.setValidator(QIntValidator())
        x.setBuddy(y)
        pp.append((x, y, "&spectrum", ".dat, .fits ...", ""))
        #####
        x = self.label_x = QLabel()
        y = self.spinbox_X = QSpinBox()
        y.valueChanged.connect(self.on_place_spectrum_edited)
        y.setMinimum(0)
        y.setMaximum(100)
        x.setBuddy(y)
        pp.append((x, y, "&x", "x-coordinate<br>(pixels; 0-based)", ""))
        #####
        x = self.label_y = QLabel()
        # TODO more elegant as spinboxes
        y = self.spinbox_Y = QSpinBox()
        y.valueChanged.connect(self.on_place_spectrum_edited)
        y.setMinimum(0)
        y.setMaximum(100)
        x.setBuddy(y)
        pp.append((x, y, "&y", "y-coordinate", ""))
        # ##### maybe later
        # x = self.label_fwhm = QLabel()
        # y = self.lineEdit_fwhm = QLineEdit()
        # y.installEventFilter(self)
        # y.textEdited.connect(self.on_place_spectrum_edited)
        # y.setValidator(QDoubleValidator(0, 10, 5))
        # x.setBuddy(y)
        # pp.append((x, y, "f&whm", "full width at<br>half-maximum (pixels)", ""))



        for i, (label, edit, name, short_descr, long_descr) in enumerate(pp):
            # label.setStyleSheet("QLabel {text-align: right}")
            assert isinstance(label, QLabel)
            label.setText(enc_name_descr(name, short_descr))
            label.setAlignment(Qt.AlignRight)
            lg.addWidget(label, i, 0)
            lg.addWidget(edit, i, 1)
            label.setToolTip(long_descr)
            edit.setToolTip(long_descr)


        l = QHBoxLayout()
        lscrw.addLayout(l)
        l.setMargin(0)
        l.addSpacerItem(QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
        b = QPushButton("&Place spectrum")
        l.addWidget(b)
        b.clicked.connect(self.go_clicked)

        a = self.twSpectra = QTableWidget()
        lscrw.addWidget(a)
        a.setSelectionMode(QAbstractItemView.MultiSelection)
        #a.currentCellChanged.connect(self.on_tableWidget_currentCellChanged)
        a.setEditTriggers(QAbstractItemView.NoEditTriggers)
        a.setFont(MONO_FONT)
        a.installEventFilter(self)



        # ##### Second tab (NEW FileSpectrumList)
        sa1 = keep_ref(QScrollArea())
        tt0.addTab(sa1, "header properties")
        sa1.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        sa1.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        # Widget that will be handled by the scrollable area
        scrw = self.scrollWidget = QWidget()
        sa1.setWidget(self.scrollWidget)
        sa1.setWidgetResizable(True)
        #        la.addWidget(w)

        lscrw = QVBoxLayout()
        scrw.setLayout(lscrw)

        alabel = keep_ref(QLabel("Create new from these parameters"))
        lscrw.addWidget(alabel)

        # Form layout
        lg = keep_ref(QGridLayout())
        lscrw.addLayout(lg)
        lg.setMargin(0)
        lg.setVerticalSpacing(4)
        lg.setHorizontalSpacing(5)
        lscrw.addSpacerItem(QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Expanding))

        # field map: [(label widget, edit widget, field name, short description, long description), ...]
        pp = self._map1 = []
        #####
        x = self.label_width = QLabel()
        y = self.spinbox_width = QSpinBox()
        y.valueChanged.connect(self.on_header_edited)
        y.setMinimum(1)
        y.setMaximum(100)
        x.setBuddy(y)
        pp.append((x, y, "&width", "hi-resolution (HR) width (pixels)", "", lambda: self.f.sky.width, lambda: self.spinbox_width.value()))
        #####
        x = self.label_height = QLabel()
        y = self.spinbox_height = QSpinBox()
        y.valueChanged.connect(self.on_header_edited)
        y.setMinimum(0)
        y.setMaximum(100)
        x.setBuddy(y)
        pp.append((x, y, "&height", "HR height (pixels)", "", lambda: self.f.sky.height, lambda: self.spinbox_height.value()))
        #####
        x = self.label_hrfactor = QLabel()
        y = self.spinbox_hrfactor = QSpinBox()
        y.valueChanged.connect(self.on_header_edited)
        y.setMinimum(1)
        y.setMaximum(100)
        x.setBuddy(y)
        pp.append((x, y, "&hrfactor", "(HR width)/(ifu width)", "", lambda: self.f.sky.hrfactor, lambda: self.spinbox_hrfactor.value()))
        #####
        x = self.label_hr_pix_size = QLabel()
        y = self.lineEdit_hr_pix_size = QLineEdit()
        y.installEventFilter(self)
        y.textEdited.connect(self.on_header_edited)
        y.setValidator(QDoubleValidator(0, 1, 7))
        x.setBuddy(y)
        pp.append((x, y, "&hr_pix_size", "HR pixel width/height (arcsec)", "", lambda: self.f.sky.hr_pix_size,
                   lambda: float(self.lineEdit_hr_pix_size.text())))
        #####
        x = self.label_hrfactor = QLabel()
        y = self.spinbox_r = QSpinBox()
        y.valueChanged.connect(self.on_header_edited)
        y.setMinimum(100)
        y.setMaximum(100000)
        y.setSingleStep(100)
        x.setBuddy(y)
        pp.append((x, y, "&R", "resolution (delta lambda)/lambda", "", lambda: self.f.sky.R, lambda: self.spinbox_r.value()))

        for i, (label, edit, name, short_descr, long_descr, f_from_f, f_from_edit) in enumerate(pp):
            # label.setStyleSheet("QLabel {text-align: right}")
            assert isinstance(label, QLabel)
            label.setText(enc_name_descr(name, short_descr))
            label.setAlignment(Qt.AlignRight)
            lg.addWidget(label, i, 0)
            lg.addWidget(edit, i, 1)
            label.setToolTip(long_descr)
            edit.setToolTip(long_descr)

        lgo = QHBoxLayout()
        lscrw.addLayout(lgo)
        #####
        bgo = self.button_revert = QPushButton("Revert")
        lgo.addWidget(bgo)
        bgo.clicked.connect(self.header_revert)
        #####
        bgo = self.button_apply = QPushButton("Apply")
        lgo.addWidget(bgo)
        bgo.clicked.connect(self.header_apply)
        #####
        bgo = keep_ref(QPushButton("Create new"))
        lgo.addWidget(bgo)
        bgo.clicked.connect(self.header_new)
        #####
        lgo.addSpacerItem(QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))


        # ##### More Tools tab
        wset = keep_ref(QWidget())
        tt0.addTab(wset, "more")
        lwset = keep_ref(QVBoxLayout(wset))
        #####
        b = keep_ref(QPushButton("Crop..."))
        lwset.addWidget(b)
        b.clicked.connect(self.crop_clicked)
        #####
        b = keep_ref(QPushButton("Export Compass Cube..."))
        lwset.addWidget(b)
        b.clicked.connect(self.export_ccube_clicked)
        #####
        lwset.addSpacerItem(QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Expanding    ))



        # #### Tabbed widget occupying right of horizontal splitter
        tt1 = self.tabWidgetVis = QTabWidget(self)
        la.addWidget(tt1)
        tt1.setFont(MONO_FONT)
        tt1.currentChanged.connect(self.current_tab_changed_vis)

        # ##### Tab containing 3D plot representation
        w0 = keep_ref(QWidget())
        tt1.addTab(w0, "plot 3D")
        # http://stackoverflow.com/questions/12459811
        self.figure0, self.canvas0, self.lfig0 = get_matplotlib_layout(w0)
        # lscrw.addLayout(lfig)

        # ##### Colors tab
        w1 = keep_ref(QWidget())
        tt1.addTab(w1, "colors")
        #####
        lw1 = QVBoxLayout(w1)
        lwset = keep_ref(QHBoxLayout())
        lw1.addLayout(lwset)
        #####
        la = keep_ref(QLabel("&Visible range"))
        lwset.addWidget(la)
        ed = self.lineEdit_visibleRange = QLineEdit("[3800., 7500.]")
        lwset.addWidget(la)
        la.setBuddy(ed)
        ed.textEdited.connect(self.on_colors_setup_edited)
        cb = keep_ref(QCheckBox("Scale colors"))
        cb.setTooltip("If checked, will make color luminosity proportional to flux area under the visible range")
        cb.stateChanged.connect(self.on_colors_setup_edited)
        #####
        self.figure1, self.canvas1, self.lfig1 = get_matplotlib_layout()


        # ##### Setup tab


        sp2.addWidget(tt0)
        sp2.addWidget(tt1)



        # ### Second widget of vertical splitter
        # layout containing description area and a error label
        wlu = QWidget()
        lu = QVBoxLayout(wlu)
        lu.setMargin(0)
        lu.setSpacing(1)
        # this was taking unnecessary space
        # x = self.c23862 = QLabel("<b>Help</b>")
        # lu.addWidget(x)
        # x = self.textEditDescr = QTextEdit(self)
        # x.setReadOnly(True)
        # x.setStyleSheet("QTextEdit {color: %s}" % COLOR_DESCR)
        # lu.addWidget(x)
        x = keep_ref(QLabel("<b>Errors</b>"))
        lu.addWidget(x)
        x = self.labelError = QLabel(self)
        x.setStyleSheet("QLabel {color: %s}" % COLOR_ERROR)
        lu.addWidget(self.labelError)


        sp.addWidget(sp2)
        sp.addWidget(wlu)

        # # Timers
        t = self.timer_place = QTimer(self)
        t.timeout.connect(self.timeout_place)
        t.setInterval(500)
        t.start()


        self.setEnabled(False)  # disabled until load() is called
        style_checkboxes(self)
        self.flag_process_changes = True



    # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * #
    # # Interface

    def load(self, x):
        assert isinstance(x, FileSpectrumList)
        self.f = x
        self.__update_from_f(True)
        # this is called to perform file validation upon loading
        # TODO probably not like this
        self.__update_f()
        self.setEnabled(True)

    # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * #
    # # Qt override

    def setFocus(self, reason=None):
        """Sets focus to first field. Note: reason is ignored."""
        # TODO self.lineEdit_titrav.setFocus()

    def eventFilter(self, source, event):
        if event.type() == QEvent.FocusIn:
            text = random_name()
            # for label, obj, name, short_descr, color, long_descr in self._map:
            #     if obj_focused == obj:
            #         text = "%s<br><br>%s" % \
            #                (enc_name(name.replace("&", ""), color), long_descr)
            #         break

            self.__set_descr_text(text)

        if event.type() == QEvent.KeyPress:
            if event.key() == Qt.Key_Delete:
                if source == self.twSpectra:
                    n_deleted = self.__delete_spectra()
                    if n_deleted > 0:
                        self.edited.emit()
        return False

        return False

    # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * #
    # # Slots

    def on_colors_setup_edited(self):
        if self.flag_process_changes:
            self.flag_update_pending = True
            # self.__update_f()

    def on_header_edited(self):

        if self.flag_process_changes:
            sth = False
            sndr = self.sender()
            for _, edit, _, _, _, f_from_f, f_from_edit in self._map1:
                changed = f_from_f() != f_from_edit()
                sth = sth or changed
                if edit == sndr:
                    _style_spinbox(self.sender(), changed)
            self.set_flag_header_changed(sth)


    def on_place_spectrum_edited(self):
        # could only update the obj_square but this is easier
        self.plot_colors()

    def go_clicked(self):
        print "GO CLICKED\n"*10
        flag_emit = False
        try:
            x, y = self.get_place_spectrum_xy()
            sp = self.choosesp.sp
            if not sp:
                raise RuntimeError("Spectrum not loaded")
            self.f.sky.add_spectrum(x, y, sp)
            self.__update_from_f()
            flag_emit = True
        except Exception as E:
            show_error(str(E))
            raise

        if flag_emit:
            self.edited.emit()

    def header_revert(self):
        self.__update_from_f_headers()

    def header_apply(self):
        # confirm overwrite if shrinking
        # perhaps don't need to discard spectra, just not use them if they are out of range!!


        print "APPLY PROPERTIES....."

    def header_new(self):
        print "CREATE NEW....."

    def current_tab_changed_vis(self):
        if self.flag_update_pending:
            self.__update_from_f()

    def current_tab_changed_options(self):
        pass

    def timeout_place(self):
        if self.obj_square:
            next_color = _ITER_COLORS_SQ.next()
            for obj in self.obj_square:
                obj.set_color(next_color)
                self.canvas1.draw()

    def crop_clicked(self):
        try:
            sky = self.f.sky

            specs = (("x_range", {"value": "[%d, %d]" % (0, sky.width - 1)}),
                     ("y_range", {"value": "[%d, %d]" % (0, sky.height - 1)}),
                     ("wavelength_range", {"value": "[%g, %g]" % (sky.wavelength[0], sky.wavelength[-1])})
                     )
            # fields = ["x_range", "y_range", "wavelength_range"]
            form = XParametersEditor(specs=specs, title="Select sub-cube")
            while True:
                r = form.exec_()
                if not r:
                    break
                kk = form.GetKwargs()
                s = ""
                try:
                    s = "x_range"
                    x0, x1 = eval(kk["x_range"])
                    s = "y_range"
                    y0, y1 = eval(kk["y_range"])
                    s = "wavelength_range"
                    lambda0, lambda1 = eval(kk["wavelength_range"])
                except Exception as E:
                    show_error("Failed evaluating %s: %s: %s" % (s, E.__class__.__name__, str(E)))
                    continue

                # Works with clone, then replaces original, to ensure atomic operation
                clone = copy.deepcopy(self.f)
                try:
                    clone.sky.crop(x0, x1, y0, y1, lambda0, lambda1)
                except Exception as E:
                    show_error("Crop operation failed: %s: %s" % (E.__class__.__name__, str(E)))
                    continue

                # Replaces original
                self.f = clone
                self.__update_from_f(True)
                break

        except Exception as E:
            show_error("Crop failed: %s" % str(E))
            raise

    def export_ccube_clicked(self):

        fn = QFileDialog.getSaveFileName(self, "Save file in %s format" % FileCCube.description,
                                         FileCCube.default_filename, "*.fits")
        if fn:
            try:
                fn = str(fn)
                ccube = self.f.sky.to_compass_cube()
                fccube = FileCCube()
                fccube.ccube = ccube
                fccube.save_as(fn)
            except Exception as E:
                show_error("Failed export: %s: %s" % (E.__class__.__name__, str(E)))
                raise

    # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * # * #
    # # Internal gear


    def get_place_spectrum_xy(self):
        x = int(self.spinbox_X.value())
        if not (0 <= x < self.f.sky.width):
            raise RuntimeError("x must be in [0, %s)" % self.f.sky.width)
        y = int(self.spinbox_Y.value())
        if not (0 <= y < self.f.sky.height):
            raise RuntimeError("y must be in [0, %s)" % self.f.sky.height)
        return x, y

    def __update_from_f(self, flag_headers=False):
        """

          flag_headers -- resets header widgets as well
        """
        self.flag_process_changes = False
        try:
            sky = self.f.sky
            assert isinstance(sky, SpectrumList)
            t = self.twSpectra
            n = len(sky.spectra)
            ResetTableWidget(t, n, 3)
            t.setHorizontalHeaderLabels(["x", "y", "spectrum"])
            i = 0
            for item in self.f.sky.spectra:
                t.insertRow(i)
                twi = QTableWidgetItem(str(item.x))
                t.setItem(i, 0, twi)
                twi = QTableWidgetItem(str(item.y))
                t.setItem(i, 1, twi)
                twi= QTableWidgetItem(item.sp.one_liner_str())
                t.setItem(i, 2, twi)
                i += 1
            t.resizeColumnsToContents()

            self.plot_spectra()
            self.plot_colors()

            if flag_headers:
                self.__update_from_f_headers()

        finally:
            self.flag_process_changes = True
            self.flag_update_pending = False

    def __update_from_f_headers(self):
        """Updates header controls only"""
        sky = self.f.sky
        self.spinbox_width.setValue(sky.width)
        self.spinbox_height.setValue(sky.height)
        self.spinbox_hrfactor.setValue(sky.hrfactor)
        self.lineEdit_hr_pix_size.setText(str(sky.hr_pix_size))
        self.spinbox_r.setValue(sky.R)
        self.set_flag_header_changed(False)

    def __set_error_text(self, x):
        """Sets text of labelError."""
        self.labelError.setText(x)

    def __set_descr_text(self, x):
        """Sets text of labelDescr."""
        self.textEditDescr.setText(x)

    def set_flag_header_changed(self, flag):
        self.button_apply.setEnabled(flag)
        self.button_revert.setEnabled(flag)
        self.flag_header_changed = flag
        if not flag:
            # If not changed, removes all eventual yellows
            for _, edit, _, _, _, _, _ in self._map1:
                _style_spinbox(edit, False)

    def __update_f(self):
        o = self.f
        emsg, flag_error = "", False
        ss = ""
        try:
            pass
            # ss = "titrav"
            # o.titrav = str(self.lineEdit_titrav.text())
            # if temp > 900:
            #     raise RuntimeError("Not prepared for depth-variable velocity "
            #      "of microturbulence (maximum allowed: 900)")
            # # Some error checks
            # ss = ""
            # if o.llzero >= o.llfin:
            #     raise RuntimeError("llzero must be lower than llfin!")
            # if not (-1 <= o.mu <= 1):
            #     raise RuntimeError("mu must be between -1 and 1!")
        except Exception as E:
            flag_error = True
            if ss:
                emsg = "Field \"%s\": %s" % (ss, str(E))
            else:
                emsg = str(E)
            # ShowError(str(E))
        self.flag_valid = not flag_error
        self.__set_error_text(emsg)


    def __delete_spectra(self):
        ii = self.twSpectra.selectedIndexes()
        for i in reversed(ii):
            del self.f.sky.spectra[i]
        self.__update_from_f()
        return len(ii)
