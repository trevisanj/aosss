from pyfant import *
from fileccube import *

fsc = FileCCube()
fsc.load("eheh.fits")

print "OK"